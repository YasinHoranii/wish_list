@extends('app')

@section('content')

    <div class="container mt-5" style="max-width: 500px">

        <div class="d-grid">
            <a href="{{route('products')}}" class="btn btn-danger">Show products</a>
            <h1></h1>
            <a href="{{ route('logout') }}" class="btn btn-danger">Sign-out</a>
        </div>
    </div>

    @yield('content')
@endsection
