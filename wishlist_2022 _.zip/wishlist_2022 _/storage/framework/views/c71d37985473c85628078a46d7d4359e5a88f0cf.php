<?php $__env->startSection('content'); ?>

    <div class="container mt-5" style="max-width: 500px">

        <div class="d-grid">
            <a href="<?php echo e(route('products')); ?>" class="btn btn-danger">Show products</a>
            <h1></h1>
            <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger">Sign-out</a>
        </div>
    </div>

    <?php echo $__env->yieldContent('content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wishlist_2022 - Copy\resources\views/auth/dashboard.blade.php ENDPATH**/ ?>